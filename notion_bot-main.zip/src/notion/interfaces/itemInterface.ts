interface item { 
    topic_id: string,
    topic_name: string,
    page_id: string,
    page_name: string
}

export default item;